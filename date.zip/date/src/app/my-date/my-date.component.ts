import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-date',
  templateUrl: './my-date.component.html',
  styleUrls: ['./my-date.component.css']
})
export class MyDateComponent implements OnInit {

  myDate:string;
  constructor() {
    //let date1=new Date();
    //this.myDate=date1.toDateString();

    setInterval(
      ()=>{
        let myDate1=new Date();
        this.myDate=myDate1.toDateString()+" "+myDate1.toLocaleTimeString()
      },2000
    )
   }

  ngOnInit() {
  }

}
