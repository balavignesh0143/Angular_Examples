import { Component, OnInit, Input } from '@angular/core';
import { Employee } from '../emp/Employee';

@Component({
  selector: 'app-emponclick',
  templateUrl: './emponclick.component.html',
  styleUrls: ['./emponclick.component.css']
})
export class EmponclickComponent implements OnInit {

  @Input("empl")employeeObj:Employee;
  isCollapsed:boolean=true;
  constructor() { }

  ngOnInit() {
  }
  check()
  {
    this.isCollapsed=!this.isCollapsed;
  }
}
