import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp2way',
  templateUrl: './emp2way.component.html',
  styleUrls: ['./emp2way.component.css'],
  /*template:`
  <p>My birthday is {{ birthday | date:format }}</p>
  <button (click)="toggleFormat()">Toggle</button>
`*/
})
export class Emp2wayComponent implements OnInit {

  employee:any;

  month=["Jan","Feb","Mar","Apr","May","June","July"];
  per="00.54565";
  constructor() {
    this.employee={
      FirstName:"bala",
      LastName:"Vignesh",
      Gender:"Male",
      Date:"03.12.1999",
      Salary:20000
    };
   }
   
   birthday = new Date(1999, 2, 12);
  toggle = true;

  get format()   { 
    return this.toggle ? 'shortDate' : 'fullDate'; 
  }
  toggleFormat() { 
    this.toggle = !this.toggle; 
  }

  ngOnInit() {
  }

}
