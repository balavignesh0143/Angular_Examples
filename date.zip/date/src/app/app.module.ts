import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MyDateComponent } from './my-date/my-date.component';
import { EmpComponent } from './emp/emp.component';
import { EmployeesComponent } from './employees/employees.component';
import { EmponclickComponent } from './emponclick/emponclick.component';
import { Emp2wayComponent } from './emp2way/emp2way.component';
import { CustomPipePipe } from './custom-pipe.pipe';
import { CPipePipe } from './c-pipe.pipe';
import { MydirectiveDirective } from './mydirective.directive';

@NgModule({
  declarations: [
    AppComponent,
    MyDateComponent,
    EmpComponent,
    EmployeesComponent,
    EmponclickComponent,
    Emp2wayComponent,
    CustomPipePipe,
    CPipePipe,
    MydirectiveDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    
    FormsModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
