import { CPipePipe } from './c-pipe.pipe';

describe('CPipePipe', () => {
  it('create an instance', () => {
    const pipe = new CPipePipe();
    expect(pipe).toBeTruthy();
  });
});
