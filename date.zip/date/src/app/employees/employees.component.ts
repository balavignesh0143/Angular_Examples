import { Component, OnInit, Input } from '@angular/core';
import { Employees } from './employees';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {

  emp:any[];
  constructor() { 
    this.emp=[
    {eid:"111",ename:"Balavignesh.P",gender:"Male",edesignation:"Son",Salary:20000,eaddress:"Tiruppur",econtact:"8807171248"},
    {eid:"222",ename:"Hsengivalab.P",gender:"Male",edesignation:"Trainee",Salary:35000,eaddress:"Coimbatore",econtact:"8680030689"},
    {eid:"333",ename:"Geetha.P",gender:"Female",edesignation:"Mother",Salary:55000,eaddress:"Palladam",econtact:"9487165163"},
    {eid:"444",ename:"Saranya.P",gender:"Female",edesignation:"Sister",Salary:15000,eaddress:"Tiruppur",econtact:"9787960464"},
    {eid:"555",ename:"Parameswaran",gender:"Male",edesignation:"Father",Salary:38040,eaddress:"Vidhyalayam",econtact:"9344704125"},
  ]
  }

  ngOnInit() {
  }

}
