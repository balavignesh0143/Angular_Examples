import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'cPipe'
})
export class CPipePipe implements PipeTransform {

  transform(Salary:any,value: any): any {
    if(Salary>35000)
    {
      return value+" = Grade A";
    }
    else if(Salary>20000)
    {
      return value+" = Grade B";
    }
    else{
      return value+" = Grade C";
    }
    
  }

}
