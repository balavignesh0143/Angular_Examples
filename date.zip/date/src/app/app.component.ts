import { Component } from '@angular/core';
import { Employee } from './emp/Employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'date';
  //myData:string;
  
  emp1:Employee;
  emp2:Employee;
  constructor() {
    //this.myData="Welcome to Angular 6!!!";
    this.emp1=new Employee();
    this.emp1.eid=111;
    this.emp1.ename="Bala";
    this.emp1.edesignation="Trainee";
    this.emp1.eaddress="CBE";
    this.emp1.esalary=20000;
    this.emp1.econtact=["8807171248","9487165163"];

    this.emp2=new Employee();
    this.emp2.eid=222;
    this.emp2.ename="Vignesh";
    this.emp2.edesignation="Trainee";
    this.emp2.eaddress="TUP";
    this.emp2.esalary=25000;
    this.emp2.econtact=["9344704125","8680030689"];
  }
}
