import { TestBed } from '@angular/core/testing';

import { DepartservService } from './departserv.service';

describe('DepartservService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DepartservService = TestBed.get(DepartservService);
    expect(service).toBeTruthy();
  });
});
