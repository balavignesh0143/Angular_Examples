import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DepartservService {

  http:HttpClient;
  dept:Department[]=[];
  constructor(http:HttpClient) { 
    this.http=http;
  }

  fetched:boolean=false;
  
  fetchDepartment()
  {
    this.http.get('./assets/departments.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }

  getDepartment():Department[]
  {
    return this.dept;
  }

  convert(data:any)
  {
    for(let o of data)
    {
      let e=new Department(o.dptId,o.dptName);
      this.dept.push(e);
    }
  }
  delete(dptId:number)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.dept.length;i++)
    {
      let e=this.dept[i];
      if(dptId==dptId)
      {
        foundIndex=i;
        break;
      }
    }
    this.dept.splice(foundIndex,1);
  }

}

export class Department
{
  dptId:any;
  dptName:any;

      constructor(dptId:any,dptName:any)
      {
        this.dptId=dptId;
        this.dptName=dptName;
      }
}
