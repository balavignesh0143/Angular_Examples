import { Component, OnInit } from '@angular/core';
import { DepartservService, Department } from '../departserv.service';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})
export class DepartmentComponent implements OnInit {

  ser:DepartservService;
  constructor(ser:DepartservService) {
    this.ser=ser;
   }
dept:Department[]=[]
delete(dptId:number)
{
  this.ser.delete(dptId);
  this.dept=this.ser.getDepartment();
}
  ngOnInit() {
    this.ser.fetchDepartment();
    this.dept=this.ser.getDepartment();
  }
}
