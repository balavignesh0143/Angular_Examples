import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-new-cmp',
  templateUrl: './new-cmp.component.html',
  styleUrls: ['./new-cmp.component.css']
})
export class NewCmpComponent implements OnInit {
  // e=new Emp();
  // a=emp1("Balavignesh",222,15000);
  // myDate:string;
  constructor() {
    // setInterval(()=>{
    //   let myDate1=new Date();
    //   this.myDate=myDate1.toDateString()+" "+myDate1.toLocaleTimeString()},1000)
   }

  ngOnInit() {
  }

}
// function emp1(name,id,salary)
//   {
//     return "Name : "+name+" ID : "+id+" Salary : "+salary;
//   }
  
// class Emp{
//   name;
//   id;
//   salary;
//   constructor()
//   {
//     this.name = "Bala"
//     this.id=123;
//     this.salary=20000;
//   }
  
//}
