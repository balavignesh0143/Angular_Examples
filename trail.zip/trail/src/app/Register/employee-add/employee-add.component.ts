import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { Transactions } from 'src/app/Models/Transactions';
import { Customer } from 'src/app/Models/Customer';
import { MyServiceService } from 'src/app/Service/my-service.service';
@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {

  createdEmployee:Customer;
  createdTransaction:Transactions;
  createdFlag:boolean=false;
  router:Router;
  service:MyServiceService;

  constructor(service:MyServiceService,router:Router) 
  {
    this.service=service;
    this.router=router;
  }


  add(data:any){
    data.caccount=data.cphone;
    data.cbalance=5000;
    this.createdEmployee=new Customer(data.caccount,data.cname,data.cphone,data.cpassword,data.ccity,data.cbalance);
    this.service.add(this.createdEmployee);
    this.createdTransaction=new Transactions("125",data.caccount,"",data.cbalance,"Account Creation");
    this.service.addTransaction(this.createdTransaction)
    alert("Added Succesfully!!!\nYour Account No. is : "+data.caccount);
    this.createdFlag=true;
    this.router.navigate(['app-employee-list']);
  }

  ngOnInit(){
  }

}
