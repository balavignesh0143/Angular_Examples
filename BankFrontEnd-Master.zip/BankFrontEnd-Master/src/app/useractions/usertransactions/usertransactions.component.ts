import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usertransactions',
  templateUrl: './usertransactions.component.html',
  styleUrls: ['./usertransactions.component.css']
})
export class UsertransactionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
