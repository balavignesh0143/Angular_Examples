import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router'
import { AlertService } from 'src/app/services/alert.service';


@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  withdrawFrom: FormGroup
  submitted:boolean = false

  constructor( private formBuilder:FormBuilder,
               private router:Router,
               private alertService:AlertService ) {
      this.formBuilder = formBuilder
   }

   ngOnInit() {

    this.withdrawFrom = this.formBuilder.group({
      amount: ['',[
        Validators.required,
        Validators.maxLength(10),
        Validators.pattern('[0-9]+')  // validates input is digit
      ]]
  });
  }

  get f() { return this.withdrawFrom.controls; }

  onSubmit(){
    this.submitted = true;

    // stop here if form is invalid
    if (this.withdrawFrom.invalid) {
        return;
    }

    
    this.alertService.success('Withdraw successful', true);
    this.router.navigate(['/useractions']);
    
  }
}
