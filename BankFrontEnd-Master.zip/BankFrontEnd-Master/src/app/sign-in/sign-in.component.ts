import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertService } from '../services/alert.service';


@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {

  
  loginForm: FormGroup;
  loading = false;
  submitted = false;



  constructor(  private formBuilder: FormBuilder,
                private router: Router,
                private alertService: AlertService) { 
    this.formBuilder = formBuilder;
    this.router = router;
}

  ngOnInit() {

    this.loginForm = this.formBuilder.group({
      accountid: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]]
    
  });
  }

  get f() { return this.loginForm.controls; }

  onSubmit(){
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
        return;
    }
    this.alertService.success('Login successful', true);
    this.router.navigate(['/useractions']);
   
  }

}
