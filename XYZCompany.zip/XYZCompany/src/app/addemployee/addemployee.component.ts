import { Component, OnInit } from '@angular/core';
import { Employee, EmployeeserviceService } from '../employeeservice.service';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'addemp',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {

  employee:Employee;//object creation for employee class
  service:EmployeeserviceService;//object creation for service class
  flag:boolean=false;//initialize the value as false

  constructor(service:EmployeeserviceService) {//passing the values within the parameters 
    this.service=service;
   }

  ngOnInit() {
  }

  add(data:any){//function for adding the data
    this.employee=new Employee(data.id,data.name,data.email,data.phone);
    this.service.add(this.employee);//passing the data child class component to service class
    alert("Saved Succesfully!!!");
    this.flag=true;
   }

}
