import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { ListemployeeComponent } from './listemployee/listemployee.component';


const routes: Routes = [
  {
    path:'addemp',//selector name of child class component
    component : AddemployeeComponent//component name of child class component
  },
  {
    path:'emplist',//selector name of child class component
    component : ListemployeeComponent//component name of child class component
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
