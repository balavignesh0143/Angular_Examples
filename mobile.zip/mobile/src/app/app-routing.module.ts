import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MobileComponent } from './mobile/mobile.component';
import { SearchComponent } from './search/search.component';


const routes: Routes = [
  {
    path:'app-search',
    component:SearchComponent
  },
  {
    path:'app-mobile',
    component:MobileComponent
  }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
