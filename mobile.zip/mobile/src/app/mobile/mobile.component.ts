import { Component, OnInit } from '@angular/core';
import { MobileService, Mobile } from '../mobile.service';

@Component({
  selector: 'app-mobile',
  templateUrl: './mobile.component.html',
  styleUrls: ['./mobile.component.css']
})
export class MobileComponent implements OnInit {

  service:MobileService;//object creation for service class

  constructor(service:MobileService) { 
    this.service=service;
  }

  mob:Mobile[]=[];//object creation for mobile class

  delete(mobId:number)//delete function for deleting the rows and passing here to service class
  {
    this.service.delete(mobId);
    this.mob=this.service.getMobiles();
  }

  column:string="mobId"; 
  order:boolean=true;
  sort(column:string)//function for sorting the column
  {    
    if(this.column==column )
    {
      this.order=!this.order;
    }
    else
    {
      this.order=true;
      this.column=column;
    }
  }
  
  ngOnInit() {//this is used for callback method
    this.service.fetch();
    this.mob=this.service.getMobiles();
  }

}
