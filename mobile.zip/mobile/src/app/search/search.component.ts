import { Component, OnInit } from '@angular/core';
import { MobileService, Mobile } from '../mobile.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  service:MobileService;

  constructor(service:MobileService) {
    this.service=service;
   }

   mob:Mobile[]=[];

  ngOnInit() {
    this.service.fetch();
  }

  isSearch:boolean=true;
  SearchData()
  {
    this.isSearch=!this.isSearch;
  }
  search(data:any)
  {
    let id:number=data.mobId;
    this.mob=this.service.search(id);
  }

}
