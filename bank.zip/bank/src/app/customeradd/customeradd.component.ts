import { Component, OnInit } from '@angular/core';
import { Customer, Transactions, CustomerServiceService } from '../customer-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customeradd',
  templateUrl: './customeradd.component.html',
  styleUrls: ['./customeradd.component.css']
})
export class CustomeraddComponent implements OnInit {

  
  createdCustomer:Customer;
  createdTransaction:Transactions;
  router:Router;
  createdFlag:boolean=false;

  service:CustomerServiceService;

  constructor(service:CustomerServiceService,router:Router) {
    this.service=service;
    this.router=router;
   }

  ngOnInit() {
  }

  add(data:any){
    data.caccount=data.cphone-100;
    data.cbalance=5000;
    
    this.createdCustomer=new Customer(data.caccount,data.cname,data.cphone,data.cpassword,data.ccity,data.cbalance);
    this.service.add(this.createdCustomer);
    
    this.createdTransaction=new Transactions("125",data.caccount,"",data.cbalance,"Account Creation");
    this.service.addTransaction(this.createdTransaction)
    alert("Added Succesfully!!!\nYour Account No. is : "+data.caccount);
    console.log(this.createdTransaction);
    this.createdFlag=true;
    this.router.navigate(['app-login']);
   }

}
