import { Component, OnInit } from '@angular/core';
import { Customer, CustomerServiceService } from '../customer-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-showbalance',
  templateUrl: './showbalance.component.html',
  styleUrls: ['./showbalance.component.css']
})
export class ShowbalanceComponent implements OnInit {

  isLogin:boolean=true;
  customer:Customer[]=[];
  cbalance:number;
  router:Router;
  isShowBalance:boolean=true;

  service:CustomerServiceService;
  constructor(service:CustomerServiceService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }

  showBalance(data:any){
    this.cbalance=this.service.showBalance(data);
    alert("Current balance : "+this.cbalance)
    this.isShowBalance=!this.isShowBalance;
    this.router.navigate(['app-homepage']);
  }

  ngOnInit() {
    this.service.fetchCustomer();
    this.customer=this.service.getCustomer();
  }

}
