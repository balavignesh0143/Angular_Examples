import { Component, OnInit } from '@angular/core';
import { CustomerServiceService, Customer } from '../customer-service.service';

@Component({
  selector: 'app-displayall',
  templateUrl: './displayall.component.html',
  styleUrls: ['./displayall.component.css']
})
export class DisplayallComponent implements OnInit {

  service:CustomerServiceService;
  customer:Customer[]=[];
  
  constructor(service:CustomerServiceService) { 
    this.service=service;
  }

  ngOnInit() {

    this.service.fetchCustomer();
    this.customer=this.service.getCustomer();
    console.log(this.customer);

  }

}
