import { Component, OnInit } from '@angular/core';
import { Customer, Transactions, CustomerServiceService } from '../customer-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-print-transaction',
  templateUrl: './print-transaction.component.html',
  styleUrls: ['./print-transaction.component.css']
})
export class PrintTransactionComponent implements OnInit {


  transactions:Transactions[]=[];
  customer:Customer[]=[];
  service:CustomerServiceService;
  router:Router;


  constructor(service:CustomerServiceService,router:Router) { 
    this.service=service;
    this.router=router;
  }

  miniStatement(data:any){
    console.log(data)
    this.transactions=this.service.miniStatement(data.caccount);
  }

  ngOnInit() {
    this.service.fetchTransactions();
    this.customer=this.service.getCustomer();
  }
}
