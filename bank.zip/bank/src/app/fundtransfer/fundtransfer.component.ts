import { Component, OnInit } from '@angular/core';
import { Transactions, CustomerServiceService } from '../customer-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-fundtransfer',
  templateUrl: './fundtransfer.component.html',
  styleUrls: ['./fundtransfer.component.css']
})
export class FundtransferComponent implements OnInit {

  isLogin:boolean=true;
  createdTransaction:Transactions;
  router:Router;
 
  service:CustomerServiceService;
  constructor(service:CustomerServiceService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }

  fundTransfer(data:any){
    let caccount_first=data.caccount;
    let caccount_second=data.caccount_second;
    let cbalance=data.cbalance;
    var ttype:string;
    ttype="Fund Transfer"
    this.service.depositeBalance(caccount_second,cbalance);
    this.service.withdrawBalance(caccount_first,cbalance);
    this.createdTransaction=new Transactions("123",caccount_first,caccount_second,data.cbalance,ttype);
    this.service.addTransaction(this.createdTransaction);
    this.router.navigate(['app-homepage']);
  }

  ngOnInit() {
  }

}
